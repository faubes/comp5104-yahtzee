# comp5104-yahtzee
Assignment 1 for COMP5104 - Object-Oriented Software Development

See https://www.youtube.com/watch?v=J4HdbAPrvFk for demo.

Command Line Yahtzee !

Installation:

Clone repositiory https://github.com/faubes/comp5104-yahtzee

Point terminal to jf-comp5104-yahtzee/ and execute

> mvn package

go to jf-comp5104-yahtzee/target/

run

> java -jar yahtzee-jar-with-dependencies.jar -s hostname port

to start a server, or

> java -jar yahtzee-jar-with-dependencies.jar  hostname port

to connect to a server! (Or use a telnet client, that works too.)
